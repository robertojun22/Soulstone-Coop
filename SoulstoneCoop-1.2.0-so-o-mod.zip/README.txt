SOULSTONE COOP 1.2.0 - local co-op for Soulstone Survivors (2 to 4 players on the same PC)
=========================================================================================

REQUIREMENTS
- Windows, with Soulstone Survivors from Steam (tested on game version 1.5d2).
- BepInEx 6 (IL2CPP), build be.788. 
- Internet on the FIRST game launch after installing: BepInEx downloads the Unity libraries and prepares its
  files. That first launch takes 1 to 3 minutes on a frozen screen. This is normal.
- One controller per extra player. Keyboard and mouse count as one player (only one keyboard per PC).

WHICH FILE TO USE
- SoulstoneCoop-1.2.0-so-o-mod.zip -> mod only, for anyone who ALREADY has BepInEx 6 IL2CPP in Soulstone Survivors.

HOW TO INSTALL
1. In Steam: right-click Soulstone Survivors > Manage > Browse local files.
   This opens the game folder (where "Soulstone Survivors.exe" is).
2. Extract ALL the contents of the zip INTO that folder, keeping the folders.
   When done, these must exist next to "Soulstone Survivors.exe":
     winhttp.dll
     doorstop_config.ini
     .doorstop_version
     dotnet\            (folder)
     BepInEx\core\      (folder)
     BepInEx\plugins\SoulstoneCoop.dll
   (The "mod only" package contains just BepInEx\plugins\SoulstoneCoop.dll.)
3. Start the game from Steam as usual and wait for the first launch to finish.

HOW TO PLAY
- On the main menu, open the "Co-op" button.
- Each player presses A on their own controller (or Enter on the keyboard) to join. The join order sets P1, P2,
  P3 and P4. B or Esc leaves. P1 confirms with START (or Enter, if on the keyboard).
- Each player picks their own hero on their turn. On an extra player's turn, the start button becomes "Ready".
- Co-op settings are in Options > "Co-op" tab (LB/RB reach it; arrows and A change the options).

ADVANCED SETTINGS (optional)
- File: BepInEx\config\SoulstoneCoop.cfg. It is created on the first launch with the default values.
- Unique-skill items dropped by killed enemies: [Coop] UniqueDropsSplitByPlayers (chance divided by the number of
  players) and UniqueItemsMaxPerHero (maximum on the map per hero, 30; 0 = no limit).
- Enemy bodies: [Coop] FasterBodies. Downed player's body thrown far away: [Death] KeepDownedBodyNear.
- This version has no test mode. If you are coming from 1.1.0 you can ignore the leftover [Testing] section in the
  config file: it no longer does anything.

WHAT'S NEW IN 1.2.0
- Unique-skill items dropped by killed enemies (Elementalist orbs, Death Knight souls, dog food, Necromancer golem
  parts...): the chance is divided by the number of players and each hero has at most 30 on the map. Before, with
  4 players, about 5 times more items dropped and they piled up on the ground.
- Menu: no longer freezes for a few seconds when leaving the hero screen while the model is still loading.
- Co-op options tab: no longer changes options by itself while the settings are closed, and no longer floods the
  log with errors while it is open.
- Fewer stutters in long matches (the mod no longer scans the whole scene from time to time).
- Enemy bodies disappear faster with more players (time on the ground is divided by the number of players).
- A downed player thrown far away by physics comes back near the group and gets up there.
- Lords: the "kill X monsters to summon" counter no longer goes negative (waves came one right after another).
- Sentinel's panther also appears when the Sentinel is not P1.
- Extra life for players 2 to 4: the game uses the shared pool the same way it does for P1 (original effect, voice
  and slow motion). A downed player with no lives left while others are standing plays the game's death slow motion
  and then returns to normal.
- Test mode removed (one controller joining as several players, P1 controlling everyone, measurements in the log).

WHAT'S NEW IN 1.1.0
- Titan Hunt: when someone enters the boss room and the gate closes, the other players come along.
- Task barriers let in whoever was left outside, and whoever is inside still cannot leave.
- Void presence event: bigger arena with more players, one group of ghosts per player, and the ghosts chase every
  player inside the arena.
- Each hero keeps their own tree and rune bonuses for skip/banish/lock and for extra lives (everyone's lives form
  a single pool). Counters, banished items and the "stats only" checkbox carry over through the portal.
- P1..P4 tags and the extras' crosshairs hide during cutscenes.

KNOWN ISSUES
- Programs that create a virtual controller (Sunshine, Parsec, DS4Windows, Steam Input in some cases) can make a
  physical controller show up twice. The Co-op screen accepts one controller at a time. If one controller moves two
  heroes, close that program or turn off its virtual controller.
- Split screen is not available yet. The camera is shared, with a "leash".

HOW TO UNINSTALL
- Mod only: delete BepInEx\plugins\SoulstoneCoop.dll.
- Everything: delete winhttp.dll, doorstop_config.ini, .doorstop_version and the BepInEx and dotnet folders from
  the game folder. Another option is Steam's "Verify integrity of game files" after deleting winhttp.dll.

SAFETY
- The mod does not use the internet, opens no ports and does not touch saves. It only reads and writes its own
  config file and the BepInEx log.
- Only download from people you trust: BepInEx loads any DLL placed in BepInEx\plugins.

Credits: BepInEx (https://github.com/BepInEx/BepInEx, LGPL-2.1 license), which includes HarmonyX and Il2CppInterop.

CHECKSUM (SHA256 of BepInEx\plugins\SoulstoneCoop.dll for version 1.2.0):
ACFD3B0EA1F73893C7A8FD7E30257BC1405D954E38B66C3E2275BDAC2486A86C
In PowerShell: Get-FileHash "BepInEx\plugins\SoulstoneCoop.dll"
